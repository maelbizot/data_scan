<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>liste des départements</title>
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
    <div>
    <h1>liste des départements</h1>
    

    <table class="table">
  <thead>
    <tr>
      <th scope="col">nom de la ville</th>
      <th scope="col"></th>
      <th scope="col">nom département</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $les_villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><a href="/ "><?php echo e($ville->REG); ?></a></td>
      <td><?php echo e($ville->CODDEP); ?></td>
      <td><a href="<?php echo e(route ('nom_departement', $ville->DEP)); ?>"><?php echo e($ville->DEP); ?></a></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>
    </body>
    
</html>










<?php /**PATH C:\Users\maelb\Desktop\anderson\Projet_DATA\datascan\resources\views//villes.blade.php ENDPATH**/ ?>