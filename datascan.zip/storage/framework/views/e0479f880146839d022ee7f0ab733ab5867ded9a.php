<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>liste des rues </title>
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
    <div>
    <h1>liste des rues à <?php echo e($ville); ?></h1>
    <h2>il y a <?php echo e($population[0]->PMUN); ?> habitans dans cette ville</h2>
       <ul class="row">
       <?php $__currentLoopData = $les_dvf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="col-sm-2">
          <?php echo e($rue->adresse_nom_voie); ?>

            <a href="<?php echo e(route ('dvf', [$rue->adresse_nom_voie, $ville])); ?>">afficher les DVF de cette rue</a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <button id="togg2">masquer les rues qui ne possèdent pas de DVF</button>
      <ul id="mael">
        <?php $__currentLoopData = $adresse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $le_reste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li >
          <?php echo e($le_reste->nom_voie); ?>

          </li>          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

</div>
    </body>
    
</html>

<style>
li{
  margin : 10px;
}
.mael{
  display : none;
}
</style>

<script>
togg2.addEventListener("click", () => {
  console.log('clicked')
  var mael= document.getElementById('mael');
  if(mael.style.display != "none"){
    mael.style.display = 'none'
  } else {
    mael.style.display = "block";
  }
})
</script><?php /**PATH C:\Users\maelb\Desktop\anderson\Projet_DATA\datascan\resources\views/rue.blade.php ENDPATH**/ ?>