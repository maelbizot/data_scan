<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>liste des villes</title>
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
    <div>
    
    <h1>liste des villes en <?php echo e($nom_du_departement->DEP); ?></h1>
    <h2>il y a <?php echo e($data_ville); ?> habitans en <?php echo e($nom_du_departement->DEP); ?> (<?php echo e($le_departement); ?>)</h2>
       <ul class="row">
       <?php $__currentLoopData = $la_ville; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="col-sm-2">
            <a href="<?php echo e(route ('rues', $ville->COM)); ?>"><?php echo e($ville->COM); ?></a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

  </tbody>
</table>

</div>
    </body>
    
</html>
<?php /**PATH C:\Users\maelb\Desktop\anderson\Projet_DATA\datascan\resources\views/villes.blade.php ENDPATH**/ ?>