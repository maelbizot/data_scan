<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>liste des départements</title>
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
    <div>
    <h1>liste des départements</h1>
    

    <table class="table">
  <thead>
    <tr>
      <th scope="col">région</th>
      <th scope="col">numéro département</th>
      <th scope="col">nom département</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $tout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($infos->REG); ?></td>
      <td><?php echo e($infos->CODDEP); ?></td>
      <td><a href="<?php echo e(route ('les_villes', $infos->CODDEP)); ?>"><?php echo e($infos->DEP); ?></a></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>
    </body>
    
</html><?php /**PATH C:\Users\maelb\Desktop\anderson\Projet_DATA\datascan\resources\views/infos.blade.php ENDPATH**/ ?>